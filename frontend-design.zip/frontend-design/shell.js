/* TSM 목업 공용 크롬(사이드바+상단바) 렌더러. fetch 미사용 → file:///http 모두 동작 */
(function () {
  var MENUS = [
    { key: "records", label: "인사기록 관리", subs: [
      { label: "교직원 정보관리", href: "/employees" },
    ] },
    { key: "appointment", label: "인사발령 관리", subs: [
      { label: "발령 등록/승인", href: "/appointments" },
      { label: "발령 이력 조회", href: "/appointments/history" },
    ] },
    { key: "attendance", label: "근태 관리", subs: [
      { label: "일일 근태 등록", href: "/attendance" },
      { label: "월 근태 현황", href: "/attendance/monthly" },
    ] },
    { key: "leaves", label: "휴가 관리", subs: [
      { label: "휴가 신청/승인", href: "/leaves" },
      { label: "잔여일수 현황", href: "/leave-balance" },
      { label: "휴가유형·정책 관리", href: "/leaves/policy" },
    ] },
    { key: "salary", label: "급여 관리", subs: [
      { label: "급여 명세서 조회", href: "/payroll" },
      { label: "수당 관리", href: "/payroll/allowance" },
      { label: "정산 엑셀 다운로드", href: "/payroll/settlement" },
    ] },
    { key: "welfare", label: "복지·증명 관리", subs: [
      { label: "경조비 신청/승인", href: "/welfare/event-support" },
      { label: "증명서 발급", href: "/welfare/certificate" },
    ] },
    { key: "dashboard", label: "통계 대시보드", subs: [
      { label: "부서별 정원 현황", href: "/dashboard/headcount" },
      { label: "당일 근태 현황", href: "/dashboard/attendance" },
    ] },
    { key: "system", label: "시스템 관리", subs: [
      { label: "권한 관리 (RBAC)", href: "/system/roles" },
      { label: "공통 코드 관리", href: "/system/codes" },
      { label: "감사로그 조회", href: "/system/audit" },
    ] },
  ];

  var LOGO_SVG =
    '<svg viewBox="0 0 24 24" fill="none">' +
    '<rect x="3" y="3" width="8" height="8" rx="2" fill="#fff" fill-opacity="0.95"/>' +
    '<rect x="13" y="3" width="8" height="8" rx="2" fill="#fff" fill-opacity="0.6"/>' +
    '<rect x="3" y="13" width="8" height="8" rx="2" fill="#fff" fill-opacity="0.6"/>' +
    '<rect x="13" y="13" width="8" height="8" rx="2" fill="#fff" fill-opacity="0.95"/></svg>';

  window.renderSidebar = function (activeKey, activeHref) {
    var el = document.querySelector(".sidebar");
    if (!el) return;
    var html =
      '<div class="logo-row"><div class="logo-badge">' + LOGO_SVG + "</div>" +
      '<div class="logo-text-wrap"><div class="logo-title">TSM</div>' +
      '<div class="logo-sub">교직원 인사관리 시스템</div></div></div>' +
      '<div class="nav-label">HR MODULES</div>';
    MENUS.forEach(function (m) {
      var active = m.key === activeKey;
      html += "<div><a href=\"#\" class=\"nav-item" + (active ? " active" : "") + "\">" + m.label + "</a>";
      if (active) {
        html += '<div class="nav-sub">';
        m.subs.forEach(function (s) {
          var on = s.href === activeHref;
          html += '<a href="#" class="' + (on ? "on" : "") + '"><span class="dot"></span>' + s.label + "</a>";
        });
        html += "</div>";
      }
      html += "</div>";
    });
    el.innerHTML = html;
  };

  window.renderTopbar = function () {
    var el = document.querySelector(".topbar");
    if (!el) return;
    el.innerHTML =
      '<div class="search-box">' +
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9AA3B2" stroke-width="2">' +
      '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>' +
      '<input type="text" placeholder="이름, 사번, 부서로 검색"></div>' +
      '<div class="user-box"><span class="notif-dot"></span>' +
      '<div class="user-avatar">관</div>' +
      '<div><div class="user-name">관리자</div><div class="user-role">ADMIN</div></div>' +
      '<button class="logout">로그아웃</button></div>';
  };

  window.renderChrome = function (activeKey, activeHref) {
    window.renderSidebar(activeKey, activeHref);
    window.renderTopbar();
  };

  /* ===== 인사기록카드 상세 (6탭 공통 렌더러) ===== */
  var REC_TABS = [
    { key: "edu",    label: "학력",   cnt: 3, add: "학력 추가",
      headers: ["학교명", "전공", "학위", "입학일", "졸업일", "상태"],
      rows: [
        ["서울대학교", "컴퓨터공학", "박사", "2001-03-02", "2007-02-25", "졸업"],
        ["서울대학교", "컴퓨터공학", "석사", "1999-03-02", "2001-02-25", "졸업"],
        ["연세대학교", "컴퓨터공학", "학사", "1995-03-02", "1999-02-25", "졸업"],
      ], mono: [3, 4] },
    { key: "career", label: "경력",   cnt: 1, add: "경력 추가",
      headers: ["기관/회사", "부서", "직위", "시작일", "종료일", "담당업무"],
      rows: [
        ["한국전자통신연구원(ETRI)", "음성언어연구실", "선임연구원", "2007-03-01", "2012-02-28", "음성인식 엔진 연구개발"],
      ], mono: [3, 4] },
    { key: "cert",   label: "자격증", cnt: 2, add: "자격증 추가",
      headers: ["자격증명", "발급기관", "자격번호", "취득일", "만료일"],
      rows: [
        ["정보처리기사", "한국산업인력공단", "06201234567", "2006-08-15", "-"],
        ["정보보안기사", "한국산업인력공단", "10201765432", "2010-05-20", "-"],
      ], mono: [2, 3, 4] },
    { key: "family", label: "가족",   cnt: 2, add: "가족 추가",
      headers: ["성명", "관계", "생년월일", "직업", "동거", "부양", "장애"],
      rows: [
        ["이영희", "배우자", "1977-06-12", "중학교 교사", "○", "○", "-"],
        ["김민준", "자녀", "2008-03-20", "학생", "○", "○", "-"],
      ], mono: [2] },
    { key: "military", label: "병역", cnt: 1, add: "병역 추가",
      headers: ["군별", "계급", "병역구분", "입대일", "전역일", "면제사유"],
      rows: [
        ["육군", "병장", "만기전역", "1995-01-05", "1997-01-04", "-"],
      ], mono: [3, 4] },
    { key: "language", label: "어학", cnt: 2, add: "어학 추가",
      headers: ["언어", "시험명", "점수/등급", "회화", "취득일", "발급기관"],
      rows: [
        ["영어", "TOEIC", "945", "상", "2020-11-01", "ETS"],
        ["일본어", "JLPT", "N2", "중", "2018-07-01", "JEES"],
      ], mono: [4] },
  ];

  window.renderEmployeeDetail = function (activeTab) {
    var el = document.querySelector(".content");
    if (!el) return;
    var active = REC_TABS.filter(function (t) { return t.key === activeTab; })[0] || REC_TABS[0];

    var html =
      '<div class="breadcrumb">인사기록 관리 <b>›</b> 교직원 정보관리 <b>›</b> 인사기록카드</div>' +
      '<div class="title-row"><div>' +
      '<div class="page-title">김정교' +
      '<span style="font-size:15px;font-weight:600;color:#8A94A6;margin-left:8px;">(FAC001)</span>' +
      '<span class="pill blue" style="margin-left:10px;vertical-align:middle;">교원</span>' +
      '<span class="pill green" style="margin-left:6px;vertical-align:middle;">재직</span></div>' +
      '<div class="page-sub">컴퓨터공학과 · 교수 · 전임(정년트랙)</div></div>' +
      '<div class="btn-row"><button class="btn-ghost">재직상태 변경</button>' +
      '<button class="btn-ghost">기본정보 수정</button>' +
      '<button class="btn-ghost">목록으로</button></div></div>';

    var info = [
      ["구분", "교원"], ["이메일", "prof.kim@tphr.com"],
      ["소속", "컴퓨터공학과"], ["연락처", "010-1234-5678"],
      ["직급", "교수"], ["생년월일", "1975-03-01"],
      ["임용구분", "전임(정년트랙)"], ["임용일", "2012-03-01"],
      ["비상연락처", "010-9876-5432"], ["주소", "서울시 관악구 관악로 1"],
    ];
    html += '<div class="info-card">';
    info.forEach(function (r) {
      html += '<div class="info-item"><span class="lbl">' + r[0] + '</span><span class="val">' + r[1] + "</span></div>";
    });
    html += "</div>";

    html += '<div class="card"><div style="padding:0 22px">';
    html += '<div class="tabs">';
    REC_TABS.forEach(function (t) {
      html += '<button class="tab-btn' + (t.key === active.key ? " on" : "") + '">' +
        t.label + '<span class="cnt">' + t.cnt + "</span></button>";
    });
    html += "</div>";
    html += '<div class="rec-toolbar"><div class="rec-title">' + active.label +
      ' 이력</div><button class="btn-sm primary">+ ' + active.add + "</button></div></div>";

    html += "<table><thead><tr>";
    active.headers.forEach(function (h) { html += "<th>" + h + "</th>"; });
    html += '<th class="right">관리</th></tr></thead><tbody>';
    active.rows.forEach(function (row) {
      html += "<tr>";
      row.forEach(function (cell, i) {
        html += "<td" + (active.mono.indexOf(i) >= 0 ? ' class="mono"' : "") + ">" + cell + "</td>";
      });
      html += '<td><div class="row-actions" style="justify-content:flex-end">' +
        '<button class="btn-sm">수정</button><button class="btn-sm danger">삭제</button></div></td></tr>';
    });
    html += "</tbody></table></div>";

    el.innerHTML = html;
  };
})();
